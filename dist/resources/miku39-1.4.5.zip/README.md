<div align="center">

# 初音未来 · Miku39

**让未来的声音，陪伴你的每一台服务器。**

为 Komari 服务器监控打造的初音未来风格主题，将青绿色、可调毛玻璃、插画背景与音乐视觉融入探针面板，在保留监控信息的同时，让日常查看服务器更有趣。

**[点击下载 Miku39 v1.4.5 主题安装包](https://github.com/vioIetMiku/komari-theme-miku39/releases/download/v1.4.5/komari-theme-miku39-v1.4.5.zip)**

效果预览：<https://github.com/vioIetMiku/komari-theme-miku39/releases/download/v1.4.5/miku39-v1.4.5-preview.html>

安装地址：<https://github.com/vioIetMiku/komari-theme-miku39/releases/download/v1.4.5/komari-theme-miku39-v1.4.5.zip>

[版本发布页](https://github.com/vioIetMiku/komari-theme-miku39/releases/tag/v1.4.5) · [详细使用说明](docs/USAGE.md) · [问题反馈](https://github.com/vioIetMiku/komari-theme-miku39/issues)

**当前版本：v1.4.5** · **原生 JavaScript / CSS** · **代码采用 MIT 许可**

![晴空初音主题封面](dist/assets/daydream.webp)

*上图为内置背景插画，不是监控页面截图。*

</div>

> 这是独立制作的 Komari 第三方主题，不是 Komari 或初音未来的官方产品。使用前需要已有的 Komari 服务；本仓库不包含探针后端。

## v1.4.5 官方主题市场兼容修复

顶层 `name` 与 `description` 改为非空字符串，以符合官方主题市场的安装包校验规则；后台配置多语言名称保留。此次仅修复元数据兼容性与更新资源版本号，监控和外观功能不变。新增元数据回归检查，防止再次提交不兼容字段。

## 有什么不一样

| 功能 | 说明 |
| --- | --- |
| 初音主题外观 | 青绿主色、深浅外观、三张内置背景，以及四款可切换或隐藏的初音伙伴。 |
| 自定义背景 | 本地选择图片或使用 HTTP(S) 图片直链；本地图片保存在当前浏览器，无需上传到 Komari 服务器。 |
| 四档显示尺寸 | 极简、紧凑、标准、放大；卡片与表格同步调整，兼顾服务器数量和阅读习惯。 |
| 可调毛玻璃 | 面板透明度、模糊强度、边框亮度可分别调节，提供清透、柔雾、清晰预设。 |
| 完整监控信息 | CPU、内存、磁盘、网络速率、累计流量、资源历史，以及后端公开提供的价格、到期和流量配额。 |
| 延迟与丢包 | 展示 Ping 任务的真实采样、曲线与统计；缺失和失败采样明确区分，不用零值掩盖未知数据。 |
| 交互地球 | 本地地理纹理、服务器位置、同坐标聚合、点击聚焦、自定义标记名称，以及上传流光示意。 |
| 音乐视觉 | 把延迟与丢包采样呈现为音轨与电平样式，可关闭；不是音频播放器。 |
| 稳定局部刷新 | 尽量复用卡片、图片、曲线与画布，避免每次实时更新都重建界面。 |
| 本地资源 | 内置壁纸、伙伴、地区 SVG 图标及地球纹理随包提供，不依赖外部 CDN、字体服务或图床。 |

## 快速安装

1. [直接下载主题安装包](https://github.com/vioIetMiku/komari-theme-miku39/releases/download/v1.4.5/komari-theme-miku39-v1.4.5.zip)，或前往 [Releases](https://github.com/vioIetMiku/komari-theme-miku39/releases) 下载 **`komari-theme-miku39-v1.4.5.zip`**。
2. 登录 Komari 管理后台，在主题管理中上传 ZIP。已有同名主题时，按后台提供的更新或覆盖流程替换。
3. 启用 **「初音未来 · Miku39」**，刷新首页；如仍显示旧资源，可尝试浏览器强制刷新。
4. 使用首页右上角的 **「切换背景」** 和 **「主题设置」** 调整外观；在后台 **「Miku 主题设置」** 中配置新访客的默认值。

**请下载 Release 中的主题安装包，而不是 GitHub 自动生成的 `Source code (zip)`。** 安装包根目录需要直接包含 `komari-theme.json` 和 `dist/`，不能再套一层仓库目录。

无需运行 npm，也无需自行编译。主题短名为 `miku39`，页面与资源位于 `dist/`。

## 按自己的习惯设置

### 背景和玻璃

- 内置背景：**晴空初音、甜梦游园、星光舞台**。
- 本地图片支持 JPG、PNG、WebP、GIF、AVIF，单个文件上限 **10 MiB**；能否显示取决于浏览器对图片格式的支持。
- 图片链接需为可直接加载的图片地址；HTTPS 页面要求使用 HTTPS 图片。
- 选择的背景与外观偏好仅在**当前站点、当前浏览器**生效，不是所有访客共享的站点配置。
- 新访客默认使用紧凑布局；已有访客保存的偏好优先于后台默认值。

### 服务器布局和地球

- 服务器较多时可选极简或紧凑，想看更大字号时可选标准或放大。
- 在位置列表中点击铅笔图标，为服务器设置自定义地球标记名称；不会改写后端服务器名称。
- 地球支持拖动、缩放、自动旋转、位置聚焦与画质切换；WebGL 不可用时回退到 Canvas 兼容绘制。
- 关闭动效或启用系统「减少动态效果」可减少持续动画；画质提供自适应、细腻、省电三档。

## v1.4.4 功能更新亮点

本版本新增**本地图片与图片链接自定义背景**，并保留此前版本的四档服务器尺寸、紧凑计费信息、自定义地球标记名称，以及资源历史、流量、价格和到期信息展示。

图片读取成功后才应用背景；类型、大小、图片解码或存储失败时保留原背景。切回内置背景或取消操作时，不再应用尚未完成的加载结果。

完整功能说明、数据口径与历史版本说明见 [详细使用说明](docs/USAGE.md)。

## 开发与验证

仓库内的 `dist/` 是可直接运行和维护的主题代码，不是需要 npm 构建的压缩产物。

**自动检查：Node.js 22 或以上。**

```sh
node tests/verify.mjs
```

本次发布准备在 Node.js 24.20.0 下运行，**84 项检查全部通过**，覆盖采样口径、局部刷新、历史数据回退、显示尺寸、标记名称和自定义背景等逻辑。GitHub Actions 会在推送和 Pull Request 时运行同一套检查。

**离线演示：Python 3，无需连接 Komari 服务。**

```sh
python -X utf8 scripts/make_preview.py
```

生成文件位于仓库同级的 `output/miku39-v1.4.5-preview.html`，直接用浏览器打开即可。演示中的六台服务器为明确标注的模拟数据，不代表真实探针。

重建地理资源需要 Python 3 与 Pillow；可选着色器验证需要 Pillow 及 Mesa EGL/OpenGL。详见 [验证记录](QA.md) 和 [地理数据说明](data/README.md)。

> 自动检查不等于真实部署验收：此次未连接实际 Komari 实例，也未完成真实浏览器中的触摸、布局、频闪和帧率测试。未声明未经验证的最低 Komari 版本或设备性能保证。

## 数据与隐私边界

- 监控数据来自当前 Komari 站点的公开接口；主题不会用演示数据填补生产环境中的缺失采样。
- 地球流光是 **服务器 → 所选汇聚点** 的视觉示意，参考在线服务器的上传速率；**不是实际流量目的地、路由追踪或跨境流量分类**。
- 优先使用已有服务器坐标；回退定位采用标明的城市或地区代表点，不调用外部 IP 地理定位服务。
- 本地图片、收藏、外观偏好和自定义名称保存于当前浏览器。清除网站数据、切换浏览器或站点地址后可能需要重新配置。
- 使用外部图片直链时，浏览器会请求对应图片服务；内置素材及本地图片不需要外部图床。

## 项目结构

```text
komari-theme.json       主题元数据与后台配置
dist/                 页面、样式、JavaScript 与本地素材
data/                 Natural Earth 原始地理数据与来源
scripts/              离线预览与资源生成脚本
tests/                自动检查与测试夹具
docs/USAGE.md          完整使用说明与版本细节
ASSETS.md             插画、图标及地理资源说明
QA.md                 原始验证记录与验收边界
REFERENCES.md         参考项目与接口来源
```

## 许可与致谢

主题**代码**采用 [MIT License](LICENSE)。插画、角色形象及其他素材的权利说明单独见 [ASSETS.md](ASSETS.md)；代码许可不代表对初音未来角色或所有插画授予同样的权利。

感谢 [Komari](https://github.com/komari-monitor/komari) 提供监控平台，以及 Natural Earth 提供地理数据。参考项目与接口来源见 [REFERENCES.md](REFERENCES.md)。

欢迎通过 [Issues](https://github.com/vioIetMiku/komari-theme-miku39/issues) 反馈问题；建议附上 Komari 版本、浏览器版本、主题版本和复现步骤，并先隐藏 IP、Token 等敏感信息。
